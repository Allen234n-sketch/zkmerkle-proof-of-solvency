# Each user file contains 100 accounts
# the file id is 0, and the invalid account counts is 10
python3 generate_user_files.py 0 100 10
# the file id is 1, and the invalid account counts is 20
python3 generate_user_files.py 1 100 20
